# This is a sample Python script.
import math

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

# Lesson 1
# task1
# x = 35
# y = 23
# print('x =', x, 'y =', y)
# ask1 = input('Hi. What's your name?')
# ask2 = int(input('On a scale of 1 to 10, how are you today?'))
# print(f"Respondent{ask1} assessed their mood as {ask2} on a scale of 1 to 10")

#Task2:
# timesec = int(input('Type time in seconds:'))
# houN = timesec // 3600
# timemin = timesec % 3600
# minN = timemin // 60
# secN = timemin % 60
# print(f'The time you entered in seconds can be represented as {houN}h:{minN}m:{secN}s')

# task3
# x = int(input('Type a number:'))
# print(f'The sum of n+nn+nnn is {x * 123}')

# task4
# x = int(input('Type a positive integer:'))
# i = 0
# last = 0
# while x > 0:
#     last1 = x % 10
#     i = i + 1
#     x = x // 10
#     if last1 > last:
#         last = last1
#     else: last = last
# print(f'Your integer has {i} digits, the biggest of which is {last}')

# task5
# rev = int(input('Type your revenue:'))
# cost = int(input('Type your costs:'))
# prof = int(rev - cost)
# if prof > 0:
#     print(f'Your profit in this period is {prof}')
#     print(f'Your marginality in this period is {prof/rev}')
#     ppe = int(input('Type your number of employees:'))
#     print(f'Your profit per employee is {prof/ppe}')
# elif profit < 0:
#     print(f'Your losses in this period are {prof}')
# elif profit == 0:
#     print(f'Your company breaks even in this period')

# task6
# start = int(input('Type the initial number of km per day:'))
# final = int(input('Type the desired number of km per day:'))
# day = math.log(1.1 * final / start, 1.1)
# start1 = start
# day1 = 0
# while start1 < final:
#    dayx = day1 + 1
#    start1 = 1.1 * start1
#    print(f'On day {dayx}, you jog {start1} km')
#print(f'With 10% daily increments, you will be able to jog {final} km after {int(day + 1)} days of training')





